#__init__.py
from GlobalData.GlobalData import *
from GlobalData.Globals import *
from GlobalData.Universe import *
