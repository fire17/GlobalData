# Universe.py

# from Globals import *
from GlobalData import GlobalData as G

def Get(gd, x):
    return gd.GetX(x)

class obj(dict):
    def __init__(self):
        self.exist = True
        self.birth = time.time()
        self.dict = {"Eyes":3, "exist":self.exist, "birth":self.birth}
        self.gd = GD
        self.root =

    def


o = obj()
print(getAllAtr(o))
print()
print(getDict(o))

'''
### DynamicData
### Storage
### Functionality
### Load and Represent
### Location
### Inputs - Mouse, Keyboard, Screen
### Draw
###
###
###
###
###
###
###
###
###
### SuperHearing
'''
